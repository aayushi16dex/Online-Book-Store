export class Book{
    _id: String;
    Title: string;
    Price: Number;
    Genre: Array<string>;
    Author: Array<String>;

}