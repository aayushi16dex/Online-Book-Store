export class User{
    _id: String;
    email: String;
    firstName: String;
    lastName: String;
    password: String;
}