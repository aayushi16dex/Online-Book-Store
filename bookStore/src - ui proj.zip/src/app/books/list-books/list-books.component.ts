import { Component } from '@angular/core';
import {BookService} from '../../services/book.service'

@Component({
  selector: 'app-list-books',
  templateUrl: './list-books.component.html',
  styleUrls: ['./list-books.component.css']
})
export class ListBooksComponent {

  bookResult: any;
  bookList: any;
  subTotal: number; 

  constructor(private bookService: BookService){
    this.getBooksList();
  }

  getBooksList(){
    this.bookService.getBooks().subscribe((data) => {
      this.bookResult = data;
      this.bookList = this.bookResult.result;
      console.log(this.bookList);
    });
  }

}
